﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LockedDoor : MonoBehaviour
{
    public float moveSpeed = 5f;
    public Transform movePoint;
    public string openDirection = "right";
    public bool doorIsOpen = false;
    AudioSource myAudioSource;

    void Start()
    {
        movePoint.parent = null;
        myAudioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);
    }

    public void RotateDoor()
    {
        gameObject.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
    }

    public void openDoor(){
        print("Opening Door");
        if( openDirection == "right" ){
            movePoint.position += new Vector3(1f, 0f, 0f);
        }
        if (openDirection == "up")
        {
            movePoint.position += new Vector3(0f, 1f, 0f);
        }
        if (openDirection == "down")
        {
            movePoint.position += new Vector3(0f, -1f, 0f);
        }
        if (openDirection == "left")
        {
            movePoint.position += new Vector3(-1f, 0f, 0f);
        }
        doorIsOpen = true;
        myAudioSource.Play();
    }

    public void closeDoor(){
        if( openDirection == "right" ){
            movePoint.position -= new Vector3(1f, 0f, 0f);
        }
        if (openDirection == "up")
        {
            movePoint.position -= new Vector3(0f, 1f, 0f);
        }
        if (openDirection == "down")
        {
            movePoint.position -= new Vector3(0f, -1f, 0f);
        }
        if (openDirection == "left")
        {
            movePoint.position -= new Vector3(-1f, 0f, 0f);
        }
        doorIsOpen = false;
    }

}
