﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class KeyObject : MonoBehaviour
{
    [SerializeField] Image keyImage;
    [SerializeField] LockedDoor doorToOpen;
    [SerializeField] AudioClip keyPickupSFX;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //SpriteRenderer m_SpriteRenderer = ;
        keyImage.gameObject.SetActive(true);
        keyImage.GetComponent<Image>().color = GetComponent<SpriteRenderer>().color;//Color.green;
        AudioSource.PlayClipAtPoint(keyPickupSFX, transform.position);
        Destroy(gameObject);

    }
}
