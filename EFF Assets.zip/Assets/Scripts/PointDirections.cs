﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointDirections : MonoBehaviour
{

    public string currentDirection = "none";

    public void undoMove(string direction){

        if( currentDirection == "right" ){
            transform.position -= new Vector3(1f, 0f, 0f);
        }else if( currentDirection == "left" ){
            transform.position -= new Vector3(-1f, 0f, 0f);
        }else if( currentDirection == "up" ){
            transform.position -= new Vector3(0f, 1f, 0f);
        }else if( currentDirection == "down" ){
            transform.position -= new Vector3(0f, -1f, 0f);
        }
        
    }


}
