﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PressurePlate : MonoBehaviour
{

    public GameObject openObject;
    public GameObject secondOpenObject;

    float trapDelay = 0.25f;

    void OnTriggerEnter2D(Collider2D col) {
        //Triggers the pressure plate to call the action of the openObject.

        print("PRESSURE PLATE ACTIVATED");
        //Destroy(openObject);

        //check tag to determine how to treat the object

        if( openObject.tag == "Fire Trap" ){
            print("fire trap activated");
            openObject.SetActive(true);
        }else{
            openObject.GetComponent<LockedDoor>().openDoor();
            if( secondOpenObject ){
                secondOpenObject.GetComponent<LockedDoor>().closeDoor();
            }
        }

        
    }

    void OnTriggerExit2D(Collider2D col){
        print("LEAVING PRESSURE PLATE");
        if( openObject.tag == "Fire Trap" ){
            StartCoroutine(TrapDelay());
            
        }else{
            openObject.GetComponent<LockedDoor>().closeDoor();
            if( secondOpenObject ){
                secondOpenObject.GetComponent<LockedDoor>().closeDoor();
            }
        }
        
        
    }

    //StartCoroutine(MovementDelay());
    IEnumerator TrapDelay(){ //Delay movment by given movementDelay float

        yield return new WaitForSeconds(trapDelay);
        openObject.SetActive(false);
    }

    /*
void Start()
    {
        //Set the tag of this GameObject to Player
        gameObject.tag = "Player";
    }

    private void OnTriggerEnter(Collider other)
    {
        //Check to see if the tag on the collider is equal to Enemy
        if (other.tag == "Enemy")
        {
            Debug.Log("Triggered by Enemy");
        }
    }

    */
}
