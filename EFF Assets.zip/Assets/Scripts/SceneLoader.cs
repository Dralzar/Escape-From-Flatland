﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    MusicPlayer musicPlayer;
    bool loadedNewLevel;
    
    void Start()
    {
        loadedNewLevel = true;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            RestartLevel();
        }

        if (loadedNewLevel)
        {
            musicPlayer = FindObjectOfType<MusicPlayer>();
            if (musicPlayer != null)
            {
                musicPlayer.SetSong();
                loadedNewLevel = false;
            }
        }
    }

    public void LoadMainMenu()
    {
        SceneManager.LoadScene("Main Menu");
        Time.timeScale = 1f;
    }

    public void LoadInstructions()
    {
        SceneManager.LoadScene("Instructions");
    }

    public void LoadSettingsMenu()
    {
        SceneManager.LoadScene("Settings Menu");
    }

    /*public void LoadLevelOne()
    {
        SceneManager.LoadScene("Level 1");
        PlayerPrefsManager.SetCheckpoint(0);
    }*/

    public void LoadNextLevel()
    {
        int currentScene = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentScene + 1);
        PlayerPrefsManager.SetCheckpoint(0);
    }

    public void RestartLevel()
    {
        int currentScene = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentScene);
        Time.timeScale = 1f;
    }

    public void QuitGame()
    {
        Time.timeScale = 1f;
        Application.Quit();
    }
}
