﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGameCamera : MonoBehaviour
{

    public Transform updatePos_1;
    public Transform updatePos_2;
    public Transform updatePos_3;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void changeCamera(int cameraNumber){
        print("MOVING CAMERA");
        if( cameraNumber == 1 ){
            transform.position = updatePos_1.position;
        }else if( cameraNumber == 2 ){
            transform.position = updatePos_2.position;
        }else if( cameraNumber == 3 ){
            transform.position = updatePos_3.position;
        }

    }
}
