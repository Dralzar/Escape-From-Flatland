﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MusicPlayer : MonoBehaviour
{
    AudioSource audioSource;
    [SerializeField] AudioClip firstSongToPlay;
    [SerializeField] AudioClip secondSongToPlay;
    [SerializeField] AudioClip thirdSongToPlay;
    [SerializeField] AudioClip fourthSongToPlay;

    void Awake()
    {
        SetUpSingleton();
    }

    void SetUpSingleton()
    {
        if (FindObjectsOfType(GetType()).Length > 1)
        {
            Destroy(gameObject);
        }
        else
        {
            DontDestroyOnLoad(gameObject);
        }
    }

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        audioSource.volume = (PlayerPrefsManager.GetMasterVolume() / 100f);
    }

    public void SetVolume(float volume)
    {
        audioSource.volume = (volume / 100f);
    }

    public void SetSong()
    {
        string levelName = SceneManager.GetActiveScene().name;
        switch (levelName)
        {
            case "Main Menu":
                if (audioSource.clip == firstSongToPlay) { return; }
                else
                {
                    audioSource.clip = firstSongToPlay;
                    audioSource.Play();
                }
                break;
            case "Level 1 (Doors and Boxes Tutorial)":
                if (audioSource.clip == firstSongToPlay) { return; }
                else
                {
                    audioSource.clip = firstSongToPlay;
                    audioSource.Play();
                }
                break;
            case "Level 4":
                if (audioSource.clip == secondSongToPlay) { return; }
                else
                {
                    audioSource.clip = secondSongToPlay;
                    audioSource.Play();
                }
                break;
            case "Level 5 (Boosters)":
                if (audioSource.clip == thirdSongToPlay) { return; }
                else
                {
                    audioSource.clip = thirdSongToPlay;
                    audioSource.Play();
                }
                break;
            case "Level 7 (End Level)":
                if (audioSource.clip == fourthSongToPlay) { return; }
                else
                {
                    audioSource.clip = fourthSongToPlay;
                    audioSource.Play();
                }
                break;
            case "End Screen":
                if (audioSource.clip == firstSongToPlay) { return; }
                else
                {
                    audioSource.clip = firstSongToPlay;
                    audioSource.Play();
                }
                break;
        }
    }
}
