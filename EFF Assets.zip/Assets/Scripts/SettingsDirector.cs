﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SettingsDirector : MonoBehaviour
{
    [SerializeField] Slider masterVolumeSlider;
    [SerializeField] TextMeshProUGUI masterVolumeTextDisplay;
    [SerializeField] float defaultMasterVolume;

    void Start()
    {
        masterVolumeSlider.value = PlayerPrefsManager.GetMasterVolume();
    }

    void Update()
    {
        MusicPlayer musicPlayer = FindObjectOfType<MusicPlayer>();
        if (musicPlayer)
        {
            musicPlayer.SetVolume(masterVolumeSlider.value);
        }
        else
        {
            print("No music player found");
        }
        masterVolumeTextDisplay.text = masterVolumeSlider.value.ToString();
    }

    public void SavePlayerPrefs()
    {
        PlayerPrefsManager.SetMasterVolume(masterVolumeSlider.value);
    }
}
