﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NPCDialogue : MonoBehaviour
{
    [SerializeField] GameObject dialogueObject;
    [SerializeField] TypewriterEffect typewriter;

    void Start()
    {
        //typewriter = GetComponentInChildren<TypewriterEffect>();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        dialogueObject.SetActive(true);
    }

    IEnumerator OnTriggerExit2D(Collider2D collision)
    {
        yield return new WaitWhile(() => typewriter.textIsFilling == true);
        //yield return new WaitForSeconds(3f);
        dialogueObject.SetActive(false);
    }
}
