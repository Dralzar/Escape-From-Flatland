﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Box : MonoBehaviour
{
    public float moveSpeed = 5f;
    public Transform movePoint;
    public LayerMask whatStopsMovement;
    public LayerMask pushedObject;

    public string pathName = "Path";

    public bool sliding = false;
    // Start is called before the first frame update
    //bool test = false;
    void Start()
    {
        //Snap Gameobject with this script to the center of the nearest tile.
        GameObject path = GameObject.Find(pathName);
        Tilemap tilemap = path.transform.GetComponent<Tilemap>();
        Vector3Int cellPosition = tilemap.WorldToCell(transform.position);
        transform.position = tilemap.GetCellCenterWorld(cellPosition);  

        movePoint.parent = null;    
       // moveBox();
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);
      //  moveBox();
    }

    void OnTriggerEnter2D(Collider2D col) {
        //print(this.transform.position.x);
        //print(col.transform.position.x);
        bool result;

        //string currentDirection = col.GetComponent<Movement>().currentDirection;
        //Only done by player...
        string currentDirection = col.GetComponent<PointDirections>().currentDirection;
        
        print(currentDirection);
        if( currentDirection == "right" ){
            result = moveBox("right");
            if(!result){
              col.GetComponent<PointDirections>().undoMove("right");
            }
        }else if( currentDirection == "left" ){
            result = moveBox("left");
            if(!result){
              col.GetComponent<PointDirections>().undoMove("left");
            }
        }else if( currentDirection == "up" ){
            result = moveBox("up");
            if(!result){
              col.GetComponent<PointDirections>().undoMove("up");
            }
        }else if( currentDirection == "down" ){
            result = moveBox("down");
            if(!result){
              col.GetComponent<PointDirections>().undoMove("down");
            }
        }

    }

    bool moveBox(string direction){

        Vector3 right = new Vector3(1f, 0f, 0f);
        Vector3 left = new Vector3(-1f, 0f, 0f);
        Vector3 up = new Vector3(0f, 1f, 0f);
        Vector3 down = new Vector3(0f, -1f, 0f);

        if(direction == "right" && !Physics2D.OverlapCircle(movePoint.position + right, 0.2f, whatStopsMovement) && !Physics2D.OverlapCircle(movePoint.position + right, 0.2f, pushedObject)){
            movePoint.position += right;
            return true;
        }else if(direction == "left" && !Physics2D.OverlapCircle(movePoint.position + left, 0.2f, whatStopsMovement) && !Physics2D.OverlapCircle(movePoint.position + left, 0.2f, pushedObject)){
            movePoint.position += left;
            return true;
        }else if(direction == "up" && !Physics2D.OverlapCircle(movePoint.position + up, 0.2f, whatStopsMovement) && !Physics2D.OverlapCircle(movePoint.position + up, 0.2f, pushedObject)){
            movePoint.position += up;
            return true;
        }else if(direction == "down" && !Physics2D.OverlapCircle(movePoint.position + down, 0.2f, whatStopsMovement) && !Physics2D.OverlapCircle(movePoint.position + down, 0.2f, pushedObject)){
            movePoint.position += down;
            return true;
        }else{
            print("CAN'T MOVE");
            return false;
        }

    }

    string checkNextTileTag(Vector3 direction){
        return Physics2D.OverlapCircle(movePoint.position + direction, 0.2f).tag;
    }
}
