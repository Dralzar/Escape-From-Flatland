﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Doormat : MonoBehaviour
{
    [SerializeField] Image keyNeededToUnlockDoor;
    [SerializeField] LockedDoor doorToOpen;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!doorToOpen.doorIsOpen && keyNeededToUnlockDoor.gameObject.activeInHierarchy)
        {
            doorToOpen.openDoor();
        }
    }
}
