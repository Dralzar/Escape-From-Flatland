﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFollow : MonoBehaviour
{

    public float moveSpeed = 5f;
    public Transform movePoint;
    public Transform tracker;

    public LayerMask whatStopsMovement;
    public LayerMask doNotTouch;

    public float enemyWaitTime = 2.0f;
    public float delayTime = 1.0f;

    float rotateRight = -90f;
    float rotateLeft = 90f;
    float rotateUp = 0f;
    float rotateDown = -180f;


    void Start()
    {
        //Any parent will automatically follow this point, defeating the purpose of the script.
        movePoint.parent = null;
        tracker.parent = null;
        //StartCoroutine(Movement());
        InvokeRepeating("Hunt", delayTime, enemyWaitTime);

    }

    // Update is called once per frame
    void Update()
    {
        //Move enemy sprite to movePoint
        transform.position = Vector3.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);
                                
    }

    void moveUp(){
        if(!Physics2D.OverlapCircle(movePoint.position + new Vector3(0f, 1f, 0f), 0.2f, whatStopsMovement) && !checkNextTile(new Vector3(0f, 1f, 0f), doNotTouch)){           
            movePoint.position += new Vector3(0f, 1f, 0f);
            movePoint.GetComponent<PointDirections>().currentDirection = "up";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateUp);                      
        }
    }

    void moveDown(){
        if(!Physics2D.OverlapCircle(movePoint.position + new Vector3(0f, -1f, 0f), 0.2f, whatStopsMovement) && !checkNextTile(new Vector3(0f, -1f, 0f), doNotTouch)){           
            movePoint.position += new Vector3(0f, -1f, 0f);
            movePoint.GetComponent<PointDirections>().currentDirection = "down";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateDown);                      
        }
    }


    void moveRight(){
        if(!checkNextTile(new Vector3(1f, 0f, 0f), whatStopsMovement) && !checkNextTile(new Vector3(1f, 0f, 0f), doNotTouch)){           
            movePoint.position += new Vector3(1f, 0f, 0f);
            movePoint.GetComponent<PointDirections>().currentDirection = "right";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateRight);                       
        }
    }


    void moveLeft(){
        if(!checkNextTile(new Vector3(-1f, 0f, 0f), whatStopsMovement) && !checkNextTile(new Vector3(-1f, 0f, 0f), doNotTouch)){           
            movePoint.position += new Vector3(-1f, 0f, 0f);
            movePoint.GetComponent<PointDirections>().currentDirection = "left";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateLeft);                       
        }
    }

    //For Diagonal Moves, in order to space them out by increments.
    bool stillToMoveUp = false;
    bool stillToMoveDown = false;
    void Hunt(){
       // printDirections();
        p("TRACKER POSITION" + tracker.position.ToString());
        p("HUNTER POSITION" + movePoint.position.ToString());
        Vector3 tPos = tracker.position;
        Vector3 hPos = movePoint.position;
       // p(tPos.x.ToString());
       // p(hPos.x.ToString());
        //Mathf.Ceil(tPos.x)
        if( stillToMoveUp ){
            moveUp();
            stillToMoveUp = false;
            return;
        }
        if( stillToMoveDown ){
            moveDown();
            stillToMoveDown = false;
            return;
        }

        if( Mathf.Ceil(tPos.x) == Mathf.Ceil(hPos.x) ){
            p("x's equal!");
            //Tracker is either above or below
            if( Mathf.Ceil(tPos.y) > Mathf.Ceil(hPos.y) ){
                //Tracker is above
                moveUp();
            }else if( Mathf.Ceil(tPos.y) < Mathf.Ceil(hPos.y) ){
                //Tracker is below
                moveDown();
            }else{
                //x and y are ==, you found the tracker!
                return;
            }
        }else if( Mathf.Ceil(tPos.y) == Mathf.Ceil(hPos.y) ){
            p("y's equal!");
            //Tracker is either above or below
            if( Mathf.Ceil(tPos.x) > Mathf.Ceil(hPos.x) ){
                //Tracker is to the right
                moveRight();
            }else if( Mathf.Ceil(tPos.x) < Mathf.Ceil(hPos.x) ){
                //Tracker is to the left
                moveLeft();
            }
        }else if( Mathf.Ceil(hPos.x) < Mathf.Ceil(tPos.x) && Mathf.Ceil(hPos.y) < Mathf.Ceil(tPos.y) ){
            //Tracker is North East
            moveRight();
            stillToMoveUp = true;
        }else if( Mathf.Ceil(hPos.x) > Mathf.Ceil(tPos.x) && Mathf.Ceil(hPos.y) < Mathf.Ceil(tPos.y) ){
            //Tracker is North West
            moveLeft();            
            stillToMoveUp = true;
        }else if( Mathf.Ceil(hPos.x) < Mathf.Ceil(tPos.x) && Mathf.Ceil(hPos.y) > Mathf.Ceil(tPos.y) ){
            //Tracker is South East
            moveRight();
            stillToMoveDown = true;
        }else if( Mathf.Ceil(hPos.x) > Mathf.Ceil(tPos.x) && Mathf.Ceil(hPos.y) > Mathf.Ceil(tPos.y) ){
            //Tracker is South West
            moveLeft();
            stillToMoveDown = true;
        }

    }

    bool checkNextTile(Vector3 direction, LayerMask layer){
        return Physics2D.OverlapCircle(movePoint.position + direction, 0.2f, layer);
    }


    void OnTriggerEnter2D(Collider2D col)
    {
        p("Enemy Has hit you!");
        if( col.tag == "Player"){
            col.GetComponent<Movement>().death();            
            
        }
        
    }


    //Debug Tools
    void p(string txt){
        print(txt);
    }

    void printDirections(){
       // p("RIGHT => " + moveRight);
       // p("LEFT => " + moveLeft);
       // p("UP => " + moveUp);
        //p("DOWN => " + moveDown);
    }
}
