﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class EnemyMovement : MonoBehaviour
{

    public float moveSpeed = 5f;
    public Transform movePoint;

    public LayerMask whatStopsMovement;
    public LayerMask doNotTouch;

    public float enemyWaitTime = 2.0f;
    public bool patrol = false;
    public int patrolDistance = 0;
    public bool moveLeft = false;
    public bool moveRight = false;
    public bool moveUp = false;

    public bool moveDown = false;

    public string pathName = "Path";

    Vector3 moveDirection;

    //test
    int currentPatrolDistance = 0;
    // Start is called before the first frame update
    void Start()
    {
        //Snap Gameobject with this script to the center of the nearest tile.
        GameObject path = GameObject.Find(pathName);
        Tilemap tilemap = path.transform.GetComponent<Tilemap>();
        Vector3Int cellPosition = tilemap.WorldToCell(transform.position);
        transform.position = tilemap.GetCellCenterWorld(cellPosition);  

        //Any parent will automatically follow this point, defeating the purpose of the script.
        movePoint.parent = null;
        //StartCoroutine(Movement());
        InvokeRepeating("Movement", 1.0f, enemyWaitTime);

        if( patrolDistance > 0 ){
            patrol = true;
        }
    }

    // Update is called once per frame
    void Update()
    {
        //Move enemy sprite to movePoint
        transform.position = Vector3.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);
                                
    }

    void Movement(){
       // printDirections();

        //gameObject.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
        float rotateRight = -90f;
        float rotateLeft = 90f;
        float rotateUp = 0f;
        float rotateDown = 180f;

        //Move Right
        if(moveRight && !checkNextTile(new Vector3(1f, 0f, 0f), whatStopsMovement) && !checkNextTile(new Vector3(1f, 0f, 0f), doNotTouch)){           
            moveDirection = new Vector3(1f, 0f, 0f);
            movePoint.position += moveDirection;
            movePoint.GetComponent<PointDirections>().currentDirection = "right";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateRight);                       
            checkPatrol();
        }
        //Move Left
        else if(moveLeft && !Physics2D.OverlapCircle(movePoint.position + new Vector3(-1f, 0f, 0f), 0.2f, whatStopsMovement) && !checkNextTile(new Vector3(-1f, 0f, 0f), doNotTouch)){           
            moveDirection = new Vector3(-1f, 0f, 0f);
            movePoint.position += moveDirection;
            movePoint.GetComponent<PointDirections>().currentDirection = "left";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateLeft);   
            checkPatrol();                       
        }
        //Move Up
        else if(moveUp && !Physics2D.OverlapCircle(movePoint.position + new Vector3(0f, 1f, 0f), 0.2f, whatStopsMovement) && !checkNextTile(new Vector3(0f, 1f, 0f), doNotTouch)){           
            moveDirection = new Vector3(0f, 1f, 0f);
            movePoint.position += moveDirection;
            movePoint.GetComponent<PointDirections>().currentDirection = "up";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateUp);
            checkPatrol();                       
        }
        //Move Down
        else if(moveDown && !Physics2D.OverlapCircle(movePoint.position + new Vector3(0f, -1f, 0f), 0.2f, whatStopsMovement) && !checkNextTile(new Vector3(0f, -1f, 0f), doNotTouch)){           
            moveDirection = new Vector3(0f, -1f, 0f);
            movePoint.position += moveDirection;
            movePoint.GetComponent<PointDirections>().currentDirection = "down";
            transform.rotation = Quaternion.Euler(0f, 0f, rotateDown);
            checkPatrol();                       
        }else if(!patrol || (!moveRight && !moveLeft && !moveDown && !moveUp)){
            return;

        }else{
            switchDirection();
            movePoint.position += (moveDirection * -1.0f);
            if( moveRight ){
                transform.rotation = Quaternion.Euler(0f, 0f, rotateRight);                       
            }else if( moveLeft ){
                transform.rotation = Quaternion.Euler(0f, 0f, rotateLeft);   
            }else if( moveUp ){
                transform.rotation = Quaternion.Euler(0f, 0f, rotateUp);
            }else if( moveDown ){
                transform.rotation = Quaternion.Euler(0f, 0f, rotateDown);
            }
            //Movement();
        }
    }

    bool checkNextTile(Vector3 direction, LayerMask layer){
        return Physics2D.OverlapCircle(movePoint.position + direction, 0.2f, layer);
    }

    void checkPatrol(){
        if( patrol ){
           // p(currentPatrolDistance + " " + patrolDistance);
            currentPatrolDistance += 1;
            
            //Reached end of patrol
            if( currentPatrolDistance >= patrolDistance ){
                currentPatrolDistance = 0;
                switchDirection();
            }
        }
    }

    void switchDirection(){
        //p("SWITCH!!");
        currentPatrolDistance = 0;
        if(moveRight){
          //  movePoint.position += new Vector3(1f, 0f, 0f);
            moveRight = false;
            moveLeft = true;
            moveUp = false;
            moveDown = false;
        }
        else if(moveLeft){
           // movePoint.position += new Vector3(-1f, 0f, 0f);
            moveLeft = false;
            moveRight = true;
            moveUp = false;
            moveDown = false;
        }
        else if(moveUp){
            //movePoint.position += new Vector3(0f, 1f, 0f);
            moveUp = false;
            moveDown = true;
            moveRight = false;
            moveLeft = false;
        }
        else if(moveDown){
            //movePoint.position += new Vector3(0f, -1f, 0f);
            moveDown = false;
            moveUp = true;
            moveRight = false;
            moveLeft = false;
        }

    }


    void OnTriggerEnter2D(Collider2D col)
    {
        p("Enemy Has hit you!");
        if(col.tag == "Player"){
            
            col.GetComponent<Movement>().death();
        }
        
    }


    //Debug Tools
    void p(string txt){
        print(txt);
    }

    void printDirections(){
        p("RIGHT => " + moveRight);
        p("LEFT => " + moveLeft);
        p("UP => " + moveUp);
        p("DOWN => " + moveDown);
    }
}
