﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boost : MonoBehaviour
{
    public bool right = true;
    public bool left = false;
    public bool up = false;
    public bool down = false;

    // Start is called before the first frame update
    bool sliding = false;
    bool startSliding = false;

    Collider2D collision;
    Vector3 direction;
    string s_direction = "right";

    float rotateRight = 0f;
    float rotateLeft = 180f;
    float rotateUp = 90f;
    float rotateDown = -90f;

    //renderer.bounds.center
    //use this ^^^^
    //to get center of boost and set player sprite to it....
    //before boost enacts.
    Movement playerObject;

    Collider2D nextTile;
    void Start()
    {
        if(right){
            transform.rotation = Quaternion.Euler(0f, 0f, rotateRight);
            s_direction = "right";
        }else if(left){
            transform.rotation = Quaternion.Euler(0f, 0f, rotateLeft);
            s_direction = "left";
        }else if(up){
            transform.rotation = Quaternion.Euler(0f, 0f, rotateUp);
            s_direction = "up";
        }else if(down){
            transform.rotation = Quaternion.Euler(0f, 0f, rotateDown);
            s_direction = "down";
        }        
    }

    // Update is called once per frame
    void Update()
    {
        if( sliding ){
            //
            Transform movePoint;
            if( collision.tag == "Block" ){
                //collision.transform.position = transform.position;
                movePoint = collision.GetComponent<Box>().movePoint;                              
            }else if( collision.tag == "Enemy" ){
                //collision.transform.position = transform.position;
                movePoint = collision.GetComponent<EnemyMovement>().movePoint;    
            }else{
                //collision.transform.position = transform.position;
                movePoint = collision.GetComponent<Movement>().movePoint;
                collision.GetComponent<Movement>().sliding = true;
            }

            //Object is directly over movePoint
            //Mathf.Ceil(tPos.x)
            if( collision.transform.position == transform.position ){
                startSliding = true;
            }
            //collision.GetComponent<Movement>().movePoint.transform.position += direction;
            if( startSliding ){ //Don't start sliding until booster and object and linned up.
                movePoint.transform.position += direction;
                nextTile = checkNextTile( direction, movePoint );
                if( nextTile ){
                    if( nextTile.tag == "Block" ){
                        print("FOUND BLOCK WHILE BOOSTING");
                        sliding = false;
                        startSliding = false;
                        collision.GetComponent<Movement>().sliding = false;                    
                    }else if( nextTile.tag == "Boost" ){
                        print("FOUND BOOST WHILE BOOSTING");
                        movePoint.transform.position += direction;
                        sliding = false;
                        startSliding = false;
                        collision.GetComponent<Movement>().sliding = false;
                    }
                }
            }

        }   
    }

    void OnTriggerEnter2D(Collider2D col) {
        print("boosting!");
        
        if( col.tag != "Player" && col.tag != "Block" ){
            return;
        }
        
        if( col.tag == "Block" ){
            playerObject = FindObjectOfType<Movement>();  
            playerObject.GetComponent<Movement>().pauseMovementStart();
        }

        if(right){
            print("boosting object to the right!");
            collision = col;
            sliding = true;
            direction = new Vector3(1f, 0f, 0f);
        }else if(left){
            print("boosting object to the left!");
            collision = col;
            sliding = true;
            direction = new Vector3(-1f, 0f, 0f);
        }else if(up){
            print("boosting object to the up!");
            collision = col;
            sliding = true;
            direction = new Vector3(0f, 1f, 0f);
        }else if(down){
            print("boosting object to the down!");
            collision = col;
            sliding = true;
            direction = new Vector3(0f, -1f, 0f);
        }
    }

    Collider2D checkNextTile(Vector3 direction, Transform movePoint){
        return Physics2D.OverlapCircle(movePoint.position + direction, 0.2f);
    }
}
