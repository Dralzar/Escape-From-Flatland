﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPrefsManager : MonoBehaviour
{
    const string MASTER_VOLUME_KEY = "Master Volume";
    const float MIN_VOLUME = 0f;
    const float MAX_VOLUME = 100f;
    const string CHECKPOINT_KEY = "Checkpoint";

    public static void SetMasterVolume(float volume)
    {
        if (volume >= MIN_VOLUME && volume <= MAX_VOLUME)
        {
            PlayerPrefs.SetFloat(MASTER_VOLUME_KEY, volume);
        }
        else
        {
            Debug.LogError("Something attempted to set Master Volume outside of the allowable range");
        }
    }

    public static float GetMasterVolume()
    {
        
        return PlayerPrefs.GetFloat(MASTER_VOLUME_KEY, 50f);
    }

    public static void SetCheckpoint(int checkpointNumber)
    {
        PlayerPrefs.SetInt(CHECKPOINT_KEY, checkpointNumber);
        print("Checkpoint set to: " + checkpointNumber);
    }

    public static int GetCheckpoint()
    {
        return PlayerPrefs.GetInt(CHECKPOINT_KEY);
    }
}
