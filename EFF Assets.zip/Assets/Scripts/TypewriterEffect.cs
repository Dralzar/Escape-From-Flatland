﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TypewriterEffect : MonoBehaviour
{
    public float typewriterDelay = 0.1f;
    private string fullText;
    private string currentText = "";
    public bool textIsFilling;

    void Start()
    {
        fullText = this.GetComponent<TextMeshProUGUI>().text;
        StartCoroutine(ShowText());
    }

    IEnumerator ShowText()
    {
        textIsFilling = true;
        for (int i = 0; i < fullText.Length + 1; i++)
        {
            currentText = fullText.Substring(0, i);
            this.GetComponent<TextMeshProUGUI>().text = currentText;
            yield return new WaitForSeconds(typewriterDelay);
        }
        textIsFilling = false;
    }
}
