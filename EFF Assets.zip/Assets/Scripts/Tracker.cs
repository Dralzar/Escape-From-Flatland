﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tracker : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    bool attached = false;
    void OnTriggerEnter2D(Collider2D col) {

        if( !attached && col.tag == "Player" ){
            attached = true;
            transform.parent = col.transform;
            gameObject.GetComponent<SpriteRenderer>().enabled = false;
        }
        

    }
}
