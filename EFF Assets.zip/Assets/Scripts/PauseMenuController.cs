﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseMenuController : MonoBehaviour
{
    [SerializeField] MenuController menuController;
    [SerializeField] GameObject pauseMenu;
    [HideInInspector] public bool gameIsPaused;
    
    void Start()
    {
        pauseMenu.SetActive(false);
        gameIsPaused = false;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (!gameIsPaused)
            {
                if (!menuController.anotherMenuIsOpen)
                {
                    pauseMenu.SetActive(true);
                    Time.timeScale = 0f;
                    gameIsPaused = true;
                }
                else if (menuController.anotherMenuIsOpen)
                {
                    return;
                }
            }
            else if (gameIsPaused)
            {
                pauseMenu.SetActive(false);
                Time.timeScale = 1f;
                gameIsPaused = false;
            }
        }
    }
}
