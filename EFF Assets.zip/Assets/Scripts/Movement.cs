﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Movement : MonoBehaviour
{
    public float moveSpeed = 5f;
    public Transform movePoint;

    public LayerMask whatStopsMovement;

    public string currentDirection = "none";

    public GameObject playerDeath;

    bool movementKeyDown = false;

    float rotateRight = -90f;
    float rotateLeft = 90f;
    float rotateUp = 0f;
    float rotateDown = -180f;

    bool dead = false;
    public bool sliding = false;

    public string pathName = "Path";

    DeathMenuController deathMenu;

    bool pauseMove = false;
    public float pauseMoveDelay = 2.0f;


    public void pauseMovementStart(){
        StartCoroutine(pauseMovement());
    }

    IEnumerator pauseMovement(){ //Delay movment by given movementDelay float

        pauseMove = true;
        yield return new WaitForSeconds(pauseMoveDelay);        
        pauseMove = false;
    }

  

    // Start is called before the first frame update
    void Start()
    {
        //Snap Gameobject with this script to the center of the nearest tile.
        GameObject path = GameObject.Find(pathName);
        Tilemap tilemap = path.transform.GetComponent<Tilemap>();
        Vector3Int cellPosition = tilemap.WorldToCell(transform.position);
        transform.position = tilemap.GetCellCenterWorld(cellPosition);  

        movePoint.parent = null;
        deathMenu = FindObjectOfType<DeathMenuController>();
    }

    public float movementDelay = 0.01f;
    bool delay = false;

    // Update is called once per frame
    void Update()
    {
        if( dead ){ return; }

        transform.position = Vector3.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);
     //   Debug.Log(Time.deltaTime);
        if( sliding ){ return; }

        if(Vector3.Distance(transform.position, movePoint.position) <= .05f && !pauseMove){ 
            
            if( Mathf.Abs(Input.GetAxisRaw("Horizontal")) == 1f && !delay ){
                StartCoroutine(MovementDelay());
                //movementKeyDown = true;
                //Check if the tile your moving to is on a collision layer
                if(!Physics2D.OverlapCircle(movePoint.position + new Vector3(Input.GetAxisRaw("Horizontal"), 0f, 0f), 0.2f, whatStopsMovement)){                    
                    movePoint.position += new Vector3(Input.GetAxisRaw("Horizontal"), 0f, 0f);
                   // print("DIRECTION Horizontal = " + Input.GetAxisRaw("Horizontal"));
                    if( Input.GetAxisRaw("Horizontal") < 0f ){
                        currentDirection = "left";
                        //In order to move boxes with the movePoint.  We have to save this value to it's own script
                        //Or the players hitbox will be what determines a box trigger.  This causes issues.
                        movePoint.GetComponent<PointDirections>().currentDirection = currentDirection;
                        //print("LEFT");
                        transform.rotation = Quaternion.Euler(0f, 0f, rotateLeft);
                    }else if (Input.GetAxisRaw("Horizontal") > 0f){                        
                        currentDirection = "right";
                        movePoint.GetComponent<PointDirections>().currentDirection = currentDirection;
                        //print("RIGHT");
                        transform.rotation = Quaternion.Euler(0f, 0f, rotateRight);
                    }
                }
                
            }

            else if( Mathf.Abs(Input.GetAxisRaw("Vertical")) == 1f  && !delay ){
                StartCoroutine(MovementDelay());
                //movementKeyDown = true;
                //Check if the tile your moving to is on a collision layer
                if(!Physics2D.OverlapCircle(movePoint.position + new Vector3(0f, Input.GetAxisRaw("Vertical"), 0f), 0.2f, whatStopsMovement)){
                    movePoint.position += new Vector3(0f, Input.GetAxisRaw("Vertical"), 0f);
                    //print("DIRECTION Vertical = " + Input.GetAxisRaw("Vertical"));
                    if( Input.GetAxisRaw("Vertical") < 0f ){
                        currentDirection = "down";
                        movePoint.GetComponent<PointDirections>().currentDirection = currentDirection;
                        //print("DOWN");
                        transform.rotation = Quaternion.Euler(0f, 0f, rotateDown);
                    }else if (Input.GetAxisRaw("Vertical") > 0f){
                        currentDirection = "up";
                        movePoint.GetComponent<PointDirections>().currentDirection = currentDirection;
                        //print("UP");
                        transform.rotation = Quaternion.Euler(0f, 0f, rotateUp);
                    }
                }
                
            }

            //if(Input.GetAxisRaw("Horizontal") == 0f && Input.GetAxisRaw("Vertical") == 0f ){
              //  movementKeyDown = false;
                
            //}

        }




    }

    public void death(){        
        gameObject.GetComponent<SpriteRenderer>().enabled = false;
        playerDeath.SetActive(true);
        deathMenu.OpenDeathMenu();
        dead = true;
    }

    //StartCoroutine(MovementDelay());
    IEnumerator MovementDelay(){ //Delay movment by given movementDelay float
        //Print the time of when the function is first called.
        //Debug.Log("Started Coroutine at timestamp : " + Time.time);
        delay = true;
        //print("movementDelay " + movementDelay);
        //yield on a new YieldInstruction that waits for 5 seconds.
        yield return new WaitForSeconds(movementDelay);
        delay = false;
        //print("movementDelay ended!");
        //After we have waited 5 seconds print the time again.
        //Debug.Log("Finished Coroutine at timestamp : " + Time.time);
    }


}
