﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Center : MonoBehaviour
{
    public string pathName = "Path";

    // Start is called before the first frame update
    void Start()
    {
        //Snap Gameobject with this script to the center of the nearest tile.
        GameObject path = GameObject.Find(pathName);
        Tilemap tilemap = path.transform.GetComponent<Tilemap>();
        Vector3Int cellPosition = tilemap.WorldToCell(transform.position);
        transform.position = tilemap.GetCellCenterWorld(cellPosition);  

    }
}
