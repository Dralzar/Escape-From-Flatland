﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalAnimation : MonoBehaviour
{
    // Start is called before the first frame update
    SpriteRenderer parent_SpriteRenderer;
    void Start()
    {


        parent_SpriteRenderer = GetComponent<SpriteRenderer>();
        SpriteRenderer[] allChildren = GetComponentsInChildren<SpriteRenderer>();
        foreach (SpriteRenderer child in allChildren)
        {
            child.color = parent_SpriteRenderer.color;
        }
        parent_SpriteRenderer.enabled = false;
        //m_SpriteRenderer = GetComponent<SpriteRenderer>();
        //Set the GameObject's Color quickly to a set Color (blue)
        //m_SpriteRenderer.color = Color.blue;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    
}
