﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Teleport : MonoBehaviour
{
    public GameObject teleportTo;
    

    private Movement movementScript;

    //For loading next level...
    public GameObject sceneLoader = null;
    public bool nextLevelPortal = false;

    private bool canTeleport = true;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D col) {
        print("TELEPORT!");
        if( canTeleport ){

            if( nextLevelPortal ){
                print("Loading Next Level");
                sceneLoader.GetComponent<SceneLoader>().LoadNextLevel();
            }else{
                Vector3 portPos = teleportTo.transform.position;
                col.transform.position = portPos;
                col.GetComponent<Movement>().movePoint.transform.position = portPos;  
                teleportTo.GetComponent<Teleport>().canTeleport = false;  


                //Tranform parent = col.GetComponent<Tranform>();                
                Transform[] allChildren = col.GetComponentsInChildren<Transform>();
                foreach (Transform child in allChildren)
                {
                    child.position = portPos;
                }
                            
            }
        }

    }

    void OnTriggerExit2D(Collider2D col){
        print("LEAVING THE PORT");
        canTeleport = true;
    }
}
