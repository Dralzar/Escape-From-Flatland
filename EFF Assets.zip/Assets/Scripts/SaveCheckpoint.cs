﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveCheckpoint : MonoBehaviour
{
    [SerializeField] int checkpointNumber;
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerPrefsManager.SetCheckpoint(checkpointNumber);
    }
}
