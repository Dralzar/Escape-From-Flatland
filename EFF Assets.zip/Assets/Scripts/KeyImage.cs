﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyImage : MonoBehaviour
{
    void Start()
    {
        gameObject.SetActive(false);
    }
}
