﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Checkpoints : MonoBehaviour
{
    public GameObject[] checkpoints;
    public string pathName = "Path";
    Movement playerObject;

    void Start()
    {        
        int lastCheckpoint = PlayerPrefsManager.GetCheckpoint();
        playerObject = FindObjectOfType<Movement>();

        foreach (GameObject point in checkpoints)
        {
            //Snap Gameobject with this script to the center of the nearest tile.
            GameObject path = GameObject.Find(pathName);
            Tilemap tilemap = path.transform.GetComponent<Tilemap>();
            Vector3Int cellPosition = tilemap.WorldToCell(point.transform.position);
            point.transform.position = tilemap.GetCellCenterWorld(cellPosition);  
        }

        if (lastCheckpoint != 0)
        {
            playerObject.transform.position = checkpoints[lastCheckpoint - 1].transform.position;
            playerObject.movePoint.transform.position = checkpoints[lastCheckpoint - 1].transform.position;
        }
    }
}
