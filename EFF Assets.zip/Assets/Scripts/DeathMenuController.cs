﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathMenuController : MonoBehaviour
{
    [SerializeField] MenuController menuController;
    [SerializeField] GameObject deathMenu;


    void Start()
    {
        deathMenu.SetActive(false);
    }

    public void OpenDeathMenu()
    {
        //if (!menuController.anotherMenuIsOpen)
        {
            deathMenu.SetActive(true);
            menuController.anotherMenuIsOpen = true;
        }
    }
}
